Opencourse course from an agent.
从中介获取的公开课资料。